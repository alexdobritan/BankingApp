package org.poo.cb;

public interface Command {
    void execute();
}
